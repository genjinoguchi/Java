Genji Noguchi's knight's tour

I didn't have help from anyone.
I thought I had a good idea for a simple way to swap between closed and open tours with an extra boolean at the top, but it didn't work.
